from django.contrib import admin
from . models import Asunto, Prioridad, Personal ,Equipo

# Register your models here.

class AsuntoAdmin(admin.ModelAdmin):

	readonly_fields=("created","updated")

class PrioridadAdmin(admin.ModelAdmin):

	readonly_fields=("created","updated")

class PersonalAdmin(admin.ModelAdmin):

	readonly_fields=("created","updated")

class EquipoAdmin(admin.ModelAdmin):

	readonly_fields=("created","updated")

admin.site.register(Asunto, AsuntoAdmin)
admin.site.register(Prioridad, PrioridadAdmin)
admin.site.register(Personal, PersonalAdmin)
admin.site.register(Equipo, EquipoAdmin)