from django.shortcuts import render, redirect
from .models import Equipo
from .forms import support
from datetime import datetime
from django.core.mail import EmailMessage
from django.db.models import Q


def con(request):
	formulario_vol=support()
	volu = Equipo.objects.all().order_by('id')
	if request.method=="POST":
		formulario_vol=support(data=request.POST)
		if formulario_vol.is_valid():
			formulario_vol.save()
			formulario_vol = support()

			return redirect("/?valido")
		else:
			return redirect("/?novalido")

	return render (request, "index.html", {'formulario':formulario_vol,"volun": volu})
